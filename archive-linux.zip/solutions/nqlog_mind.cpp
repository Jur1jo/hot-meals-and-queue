#include <iostream>
#include <vector>

using namespace std;

const int N = (1 << 17);

int t[2 * N];
int mod[2 * N];

int n;

void build(int v, int l, int r, vector<int> &a) {
    if (r - l == 1) {
        t[v] = a[l] - l;
        return;
    }

    int m = (l + r) / 2;
    build(v * 2 + 1, l, m, a);
    build(v * 2, m, r, a);
    t[v] = max(t[v * 2 + 1], t[v * 2]);
}

void push(int v) {
    t[v * 2 + 1] += mod[v];
    t[v * 2] += mod[v];
    mod[v * 2 + 1] += mod[v];
    mod[v * 2] += mod[v];
    mod[v] = 0;
}

int get_first_more(int v, int l, int r, int L, int R, int val) {
    if (R <= l || r <= L || t[v] <= val)
        return -1;
    if (r - l == 1)
        return l;

    push(v);
    int m = (l + r) / 2;
    int res = get_first_more(v * 2, m, r, L, R, val);
    if (res == -1)
        res = get_first_more(v * 2 + 1, l, m, L, R, val);
    return res;
}

int get_val(int v, int l, int r, int L, int R) {
    if (r <= L || R <= l)
        return -1e9;
    if (L <= l && r <= R)
        return t[v];

    push(v);
    int m = (l + r) / 2;
    return max(get_val(v * 2 + 1, l, m, L, R), get_val(v * 2, m, r, L, R));
}

int get_val(int pos) {
    return get_val(1, 0, n, pos, pos + 1);
}

void update(int v, int l, int r, int L, int R, int val) {
    if (R <= l || r <= L)
        return;
    if (L <= l && r <= R) {
        t[v] += val;
        mod[v] += val;
        return;
    }

    push(v);
    int m = (l + r) / 2;
    update(v * 2 + 1, l, m, L, R, val);
    update(v * 2, m, r, L, R, val);
    t[v] = max(t[v * 2 + 1], t[v * 2]);
}

int get(int l, int r) {
    int ans = r - l + 1;
    while (r >= l)
        --ans, r = get_first_more(1, 0, n, 0, r, get_val(r));
    return ans;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; ++i)
        cin >> a[i];
    build(1, 0, n, a);
    cout << get(0, n - 1) << '\n';

    int q;
    cin >> q;
    while (q--) {
        int t, l, r;
        cin >> t >> l >> r;
        if (t == 1) {
            cout << get(l - 1, r - 1) << '\n';
        } else {
            int val;
            cin >> val;
            update(1, 0, n, l - 1, r, val);
        }
    }
}
