#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <bitset>
using namespace std;

#ifdef LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__);fflush(stderr);
#else
	#define eprintf(...) 42
#endif

using ll = long long;
using ld = long double;
using uint = unsigned int;
using ull = unsigned long long;
template<typename T>
using pair2 = pair<T, T>;
using pii = pair<int, int>;
using pli = pair<ll, int>;
using pll = pair<ll, ll>;
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
ll myRand(ll B) {
	return (ull)rng() % B;
}

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

clock_t startTime;
double getCurrentTime() {
	return (double)(clock() - startTime) / CLOCKS_PER_SEC;
}

const int N = 500500;
int n, q;
int a[N];
int pref[N];
map<pii, int> mem;

int solve(int l, int r) {
	if (mem.empty()) {
		int bal = 0;
		for (int i = 0; i <= n; i++) {
			bal += pref[i];
			pref[i] = 0;
			a[i] += bal;
		}
	}
	pii P = mp(l, r);
	if (mem.count(P)) return mem[P];
	int res = 0;
	int w = 0;
	for (int i = r - 1; i >= l; i--) {
		if (w > a[i]) {
			w--;
			res++;
		} else {
			w = a[i];
		}
	}
	mem[P] = res;
	return res;
}

int main()
{
	startTime = clock();
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &a[i]);
	scanf("%d", &q);
	printf("%d\n", solve(0, n));
	while(q--) {
		int t, l, r;
		scanf("%d%d%d", &t, &l, &r);
		l--;
		if (t == 1) {
			printf("%d\n", solve(l, r));
		} else {
			int x;
			scanf("%d", &x);
			mem.clear();
			pref[l] += x;
			pref[r] -= x;
		}
	}

	return 0;
}
