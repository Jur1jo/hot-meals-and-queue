#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <bitset>
using namespace std;

#ifdef LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__);fflush(stderr);
#else
	#define eprintf(...) 42
#endif

using ll = long long;
using ld = long double;
using uint = unsigned int;
using ull = unsigned long long;
template<typename T>
using pair2 = pair<T, T>;
using pii = pair<int, int>;
using pli = pair<ll, int>;
using pll = pair<ll, ll>;
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
ll myRand(ll B) {
	return (ull)rng() % B;
}

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

clock_t startTime;
double getCurrentTime() {
	return (double)(clock() - startTime) / CLOCKS_PER_SEC;
}

const int INF = (int)1e9;
const int N = 1 << 19;
struct Node {
	int l, r;
	int maxVal;
	int cnt;
	int addTo;

	Node() : l(), r(), maxVal(), cnt(), addTo() {}
	Node(int _l, int _r) : l(_l), r(_r), maxVal(0), cnt(1), addTo(0) {}

	void add(int x) {
		maxVal += x;
		addTo += x;
	}
};
Node tree[2 * N + 5];

void build() {
	for (int i = 0; i < N; i++)
		tree[N + i] = Node(i, i + 1);
	for (int i = N - 1; i > 0; i--)
		tree[i] = Node(tree[2 * i].l, tree[2 * i + 1].r);
}
void push(int v) {
	assert(v < N);
	if (tree[v].addTo == 0) return;
	for (int u = 2 * v; u < 2 * v + 2; u++) {
		tree[u].add(tree[v].addTo);
	}
	tree[v].addTo = 0;
}

int getOnSegm(int v, int l, int r, int &x) {
	if (x >= tree[v].maxVal || l >= tree[v].r || tree[v].l >= r) return 0;
	if (v >= N) {
		x = tree[v].maxVal;
		return 1;
	}
	push(v);
	if (l <= tree[v].l && tree[v].r <= r) {
		if (x >= tree[2 * v].maxVal) {
			return getOnSegm(2 * v + 1, l, r, x);
		} else {
			int res = getOnSegm(2 * v, l, r, x) + tree[v].cnt - tree[2 * v].cnt;
			x = max(x, tree[2 * v + 1].maxVal);
			return res;
		}
	}
	int res = getOnSegm(2 * v, l, r, x);
	return res + getOnSegm(2 * v + 1, l, r, x);
}

void update(int v) {
	assert(v < N);
	tree[v].maxVal = max(tree[2 * v].maxVal, tree[2 * v + 1].maxVal);
	int w = tree[2 * v].maxVal;
	tree[v].cnt = tree[2 * v].cnt + getOnSegm(2 * v + 1, tree[v].l, tree[v].r, w);
}

void addOnSegm(int v, int l, int r, int x) {
	if (l <= tree[v].l && tree[v].r <= r) {
		tree[v].add(x);
		return;
	}
	if (l >= tree[v].r || tree[v].l >= r) return;
	push(v);
	for (int u = 2 * v; u < 2 * v + 2; u++)
		addOnSegm(u, l, r, x);
	update(v);
}

int n, q;
int a[N];

int main()
{
	startTime = clock();
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		a[i] -= i;
	}
	reverse(a, a + n);
	build();
	for (int i = 0; i < n; i++)
		tree[N + i].maxVal = a[i];
	for (int i = N - 1; i > 0; i--)
		update(i);
	int W = -INF;
	printf("%d\n", n - getOnSegm(1, 0, n, W));
	scanf("%d", &q);
	while(q--) {
		int t, l, r;
		scanf("%d%d%d", &t, &l, &r);
		l--;
		swap(l, r);
		l = n - l;
		r = n - r;
		if (t == 1) {
			int W = -INF;
			printf("%d\n", r - l - getOnSegm(1, l, r, W));
		} else {
			int x;
			scanf("%d", &x);
			addOnSegm(1, l, r, x);
		}
	}

	return 0;
}
