#include "testlib.h"

using namespace std;

const int MAXN = 5e5;
const int MAX_VAL = 1e9;

struct SegTree {
    vector<long long> t;
    vector<long long> mod;
    int sz = 1, type;
    long long zero_val;

    long long merge(long long a, long long b) {
        if (type == 0)
            return min(a, b);
        return max(a, b);
    }

    void push(int v) {
        t[v * 2 + 1] += mod[v];
        t[v * 2] += mod[v];
        mod[v * 2 + 1] += mod[v];
        mod[v * 2] += mod[v];
        mod[v] = 0;
    }

    void build(int v, int l, int r, vector<int>& a) {
        if (r - l == 1) {
            t[v] = a[l];
            return;
        }

        int m = (l + r) / 2;
        build(v * 2 + 1, l, m, a);
        build(v * 2, m, r, a);
        t[v] = merge(t[v * 2 + 1], t[v * 2]);
    }

    long long get(int v, int l, int r, int L, int R) {
        if (R <= l || r <= L)
            return zero_val;
        if (L <= l && r <= R)
            return t[v];

        push(v);
        int m = (l + r) / 2;
        return merge(get(v * 2 + 1, l, m, L, R), get(v * 2, m, r, L, R));
    }

    void update(int v, int l, int r, int L, int R, int val) {
        if (R <= l || r <= L)
            return;
        if (L <= l && r <= R) {
            t[v] += val;
            mod[v] += val;
            return;
        }

        push(v);
        int m = (l + r) / 2;
        update(v * 2 + 1, l, m, L, R, val);
        update(v * 2, m, r, L, R, val);
        t[v] = merge(t[v * 2 + 1], t[v * 2]);
    }

    SegTree(int n, vector<int> a, int _type) {
        type = _type, zero_val = (type == 0) ? 1 : -1e18;
        while (sz <= n * 2)
            sz *= 2;
        t.resize(sz);
        mod.resize(sz);
        build(1, 0, n, a);
    }
};

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int n = inf.readInt(3, MAXN, "Too small or too much n");
    inf.readEoln();
    vector<int> a = inf.readInts(n, 0, n - 1, "A_i less zero or more n - 1");
    inf.readEoln();
    SegTree mn(n, a, 0);
    SegTree second_mx(n, a, 1);
    for (int i = 0; i < n; ++i)
        a[i] -= i;
    SegTree mx(n, a, 1);

    inf.ensuref(mn.get(1, 0, n, 0, n) >= 0 && mx.get(1, 0, n, 0, n) <= 0, "No answer in start array");
    int q = inf.readInt(0, MAXN, "Too many queries");
    inf.readEoln();
    while (q--) {
        int type = inf.readInt(1, 2, "Wrong type");
        inf.readSpace();
        int l = inf.readInt(1, n, "l_i less 1 or l_i more n");
        inf.readSpace();
        int r = inf.readInt(l, n, "r_i less l_i or r_i more n");
        if (type == 1) {
            inf.ensuref(mn.get(1, 0, n, l - 1, r) >= 0 && mx.get(1, 0, n, l - 1, r) <= -l + 1, "No answer in segment");
        } else {
            inf.readSpace();
            int val = inf.readInt(-n + 1, n - 1, "Val is too much or small");
            mn.update(1, 0, n, l - 1, r, val);
            mx.update(1, 0, n, l - 1, r, val);
            second_mx.update(1, 0, n, l - 1, r, val);
            inf.ensuref(abs(second_mx.get(1, 0, n, 0, n)) <= MAX_VAL, "Too much value");
        }
        inf.readEoln();
    }
    inf.readEof();
}
