#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int q = atoi(argv[2]);
    int start_zero = 1000; // Сколько нулей вначале
    int start_add = 2000; // С какой позиции мы обновляем отрезок
    int min_val = 777; // Чему равен максимальный элемент
    int probability_query_ans = atoi(argv[3]); // С какой вероятностью мы спрашиваем про отрезок

    cout << n << '\n';
    vector<int> a(n);
    for (int i = 0; i < start_zero; ++i)
        a[i] = 0;
    for (int i = start_zero; i < start_add; ++i)
        a[i] = rnd.wnext(0, i - start_zero + 1, -3);
    for (int i = start_add; i < n; ++i)
        a[i] = rnd.wnext(min_val, i - start_zero, -20);
    for (int i = 0; i < n - 1; ++i)
        cout << a[i] << ' ';
    cout << a[n - 1] << '\n';
    cout << q << '\n';

    long long now_val = min_val;
    int l_query_mod = rnd.wnext(start_add, n, -3);
    int r_query_mod = rnd.wnext(l_query_mod, n, 15);
    while (q--) {
        if (rnd.next(0, 1000) <= probability_query_ans) {
            int l = rnd.wnext(1, start_zero, -5);
            int r = rnd.wnext(l, n, 7);
            cout << 1 << ' ' << l << ' ' << r << '\n';
        } else {
            int want_val = rnd.next(0, min_val);
            cout << 2 << ' ' << l_query_mod << ' ' << r_query_mod << ' ' << want_val - now_val << '\n';
            now_val = want_val;
        }
    }
}
